// Déplacer ce fichier dans un dossier utils car ce n'est pas un hook React
// mais plutôt un utilitaire pour charger Google Maps

// Contenu du fichier à conserver tel quel
