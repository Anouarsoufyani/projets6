import React from "react";

const GestionLivreurPage = () => {
    return <div>GestionLivreurPage</div>;
};

export default GestionLivreurPage;
