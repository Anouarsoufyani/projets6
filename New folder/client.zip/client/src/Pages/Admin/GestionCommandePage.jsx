import React from "react";

const GestionCommandePage = () => {
    return <div>GestionCommandePage</div>;
};

export default GestionCommandePage;
