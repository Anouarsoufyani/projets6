const GestionCommandePage = () => {
    return <div className="w-full h-full p-6">GestionCommandePage</div>;
};

export default GestionCommandePage;
