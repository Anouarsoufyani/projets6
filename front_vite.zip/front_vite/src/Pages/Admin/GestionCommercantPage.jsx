import React from "react";

const GestionCommercantPage = () => {
    return <div>GestionCommercantPage</div>;
};

export default GestionCommercantPage;
