const GestionCommandePage = () => {
  return <div>GestionCommandePage</div>
}

export default GestionCommandePage
