const GestionCommandePage = () => {
  return <div className="w-full h-full bg-gradient-to-br from-emerald-50 to-teal-100 p-6">GestionCommandePage</div>
}

export default GestionCommandePage
